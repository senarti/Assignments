#ifndef TFTPCLIENT
#define TFTPCLIENT

#include "tftp_packet.h"

#define TFTP_CLIENT_SERVER_TIMEOUT 2000

#define TFTP_CLIENT_ERROR_TIMEOUT 0
#define TFTP_CLIENT_ERROR_SELECT 1
#define TFTP_CLIENT_ERROR_CONNECTION_CLOSED 2
#define TFTP_CLIENT_ERROR_RECEIVE 3
#define TFTP_CLIENT_ERROR_NO_ERROR 4
#define TFTP_CLIENT_ERROR_PACKET_UNEXPECTED 5


// global variables
using namespace std;
const int backLog = 3;
const int maxDataSize = 1460;

class TFTPClient {

	private:

		char* server_ip;
		int	server_port;

		
		int socket_descriptor;

		
		struct sockaddr_in client_address;
		int connection;

		TFTP_Packet received_packet;

	protected:

		int sendBuffer(char *);
		int sendPacket(TFTP_Packet* packet);

	public:

		TFTPClient(char* ip, int port);
      		~TFTPClient();

		int connectToServer();
                void Socket_descriptor(int socketfd ) { socket_descriptor = socketfd; }
                int getSocket_descriptor(){return socket_descriptor;}
		bool getFile(char* filename, char* buff);
		

		int waitForPacket(TFTP_Packet* packet, int timeout_ms = TFTP_CLIENT_SERVER_TIMEOUT);
		bool waitForPacketACK(int packet_number, int timeout_ms = TFTP_CLIENT_SERVER_TIMEOUT);
		int waitForPacketData(int packet_number, int timeout_ms = TFTP_CLIENT_SERVER_TIMEOUT);

		void errorReceived(TFTP_Packet* packet);

};

class ETFTPSocketCreate: public std::exception {
  virtual const char* what() const throw() {
    return "Unable to create a socket";
  }
};

class ETFTPSocketInitialize: public std::exception {
  virtual const char* what() const throw() {
    return "Unable to find socket library";
  }
};


// this function received data from the server and stores it in rcvDataBuf array
void recv_data(int , int );


// this function sends data taken from the terminal to the server
void send_data(int , int );


// converts char array to string
string convertToString(char* , int );


// finding index of value K in a vector v(K is always present in v)
int getIndex(vector<int> , int );
void WelComeMsg();

void DEBUGMSG(char*);

#endif

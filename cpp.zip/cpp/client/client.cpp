/**

	TFTP Server
	Name: Artisen [ group_05]
	Sprint Proejct: TFTP based on UDP

**/

#include "../server/main.h"
#include "tftp_client.h"
#include "lib/anyoption.h"

using namespace std;

//#define COMMAND_PUT 1
//#define COMMAND_GET 2

int main(int C, char *V[]) {

	char* ip = V[1];

        char* buff;
        char* filename;
	
	int port;
              /*
                if(argc != 3)
	       {
		cerr<<"Useage: app ipaddress portno"<<endl;
		exit(EXIT_FAILURE);
	         }*/

                /*argv[1]=IP Address of the serrver , argv[2]=Port No,
	argv[3]=file name to be fetched*/
	if (V[1] == NULL) {
		printf ("Enter the IP address of server. \n");
		exit(0);
	}

	if (V[2] == NULL) {
		printf ("Enter the port number for the server. \n");
		exit(0);
	}

	if (V[3] == NULL) {
		printf ("PL specfiy the file to be fetched. \n");
		exit(0);
	}

	cout << "Starting TFTP client\n";
     
	TFTPClient client(ip, atoi(V[2]));
        
	if (client.connectToServer() != 1) {

		cout << "Error while connecting to server " << endl;

		return 0;
	  
	}   

                 WelComeMsg();
                 //cout<<filename <<endl;
                 char rcvDataBuf[maxDataSize];
                 int socket_descriptor=client.getSocket_descriptor();

                 cout<<"Send the file name buff"<<endl;
                 send(socket_descriptor, "1", 2, 0);
                 memset(&rcvDataBuf, 0, maxDataSize);
                 //recv(newClientFd, rcvDataBuf, maxDataSize, 0);
                  recv(socket_descriptor, rcvDataBuf, sizeof(rcvDataBuf), 0);
                  cout<<"From Server: "<<rcvDataBuf<<endl;

		if (client.getFile(filename, buff)) {
                       strcpy(filename,buff);

			cout << "File downloaded successfully\n";

		} else {

			cout << "Error has occured in file transfer\n";

		}
		  


	client.~TFTPClient();

	cout << "Disconnected from server" << endl;

	return 1;

}
/**

	TFTP Server
	Name: Artisen [ group_05]
	Sprint Proejct: TFTP based on UDP

**/

#include "../server/main.h"
#include "tftp_client.h"
#include "anyoption.h"

using namespace std;

#define COMMAND_PUT 1
#define COMMAND_GET 2

int main(int argc, char ** argv) {

	char* ip = "";
	int	  port;
        char* buff;
        char* filename;

        
	cout << "Starting TFTP client\n";
     
	TFTPClient client(ip, port);
        
	if (client.connectToServer() != 1) {

		cout << "Error while connecting to server " << endl;

		return 0;
	  
	}

	//if (command == COMMAND_GET) {
		strcpy(filename,buff);

		if (client.getFile(filename, buff)) {

			cout << "File downloaded successfully\n";

		} else {

			cout << "Error has occured in file transfer\n";

		}
		
	//}


	client.~TFTPClient();

	cout << "Disconnected from server" << endl;

	return 1;

}
#ifndef TFTP_UTILS
#define TFTP_UTILS

#define DEBUGMSG(x) DEBUGMSG(x)

void DEBUGMSG(char* message) {
	std::cout << message << endl;
}

#endif
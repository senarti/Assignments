/**

	TFTP Server
	Name: Artisen [ group_05]
	Sprint Proejct: TFTP based on UDP

**/

#include "main.h"
#include "tftp_server.h"
#include "lib/anyoption.h"

using namespace std;

int main(int argc, char **  argv) {

	int port = TFTP_DEFAULT_PORT;

	cout << "Starting TFTP server on port " << endl;

	#ifdef DEBUG
		TFTPServer server(port, "ftproot/");
	#else
		TFTPServer server(port, "ftproot/");
	#endif
		
	cout << "TFTP Server was shut down" << endl;

	return 1;

}

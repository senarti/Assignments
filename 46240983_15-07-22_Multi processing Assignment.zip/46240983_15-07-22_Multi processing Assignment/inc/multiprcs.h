#include<iostream>
#include<sys/types.h>
#include<sys/wait.h>
#include<unistd.h>
#include<fstream>
#include<string>
#define SIZE 200

using namespace std;